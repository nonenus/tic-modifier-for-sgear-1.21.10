================================================================
  MODIFIER WORKBENCH MOD
  For Minecraft 1.21.1 + NeoForge 21.1.172+ + Silent Gear 3.6+
================================================================

OVERVIEW
--------
This mod adds a Modifier Workbench block that lets you apply Silent Gear
modifiers directly to your gear without tokens, scoreboards, or GUIs
that require manual data manipulation.

FEATURES
---------
  1. Modifier Workbench block — craft and place it like any other block
  2. Fortune (lapis), Mining Speed (redstone), Weapon Damage (quartz)
  3. Tier system based on total material quantity:
       Tier I   =  50+ items
       Tier II  = 150+ items
       Tier III = 300+ items
  4. Tip upgrade removed from Silent Gear's part registry
  5. Silent Gear items cannot be enchanted via enchanting table or anvil


HOW TO BUILD THE MOD
---------------------
Requirements:
  - Java 21 (JDK)
  - Git (to download the NeoForge MDK/Gradle wrapper)
  - Internet connection (Gradle downloads dependencies automatically)

Steps:
  1. Open a terminal in this folder (modifier_workbench_mod/)

  2. Download the Gradle wrapper JAR (required first time):
       On Windows:   gradlew.bat
       On Mac/Linux: chmod +x gradlew && ./gradlew

  3. Get the Silent Gear JAR and place it in:
       run/mods/silent-gear-1.21.1-*.jar
     (Download from: https://www.curseforge.com/minecraft/mc-mods/silent-gear)
     This is needed so your IDE / Gradle can see SG's classes at compile time.

  4. Build the mod:
       ./gradlew build
     Output JAR: build/libs/modifierworkbench-1.0.0.jar

  5. Copy the output JAR to your Minecraft mods folder.

NOTE: You also need to download the Gradle wrapper JAR manually since
      this source folder does not include gradle/wrapper/gradle-wrapper.jar
      (binary files are excluded). Run:
        ./gradlew wrapper --gradle-version=8.8
      Or download the NeoForge MDK from:
        https://neoforged.net/
      and copy the gradle/wrapper/ folder from there.


USAGE
------
Crafting:
  D I D        D = Diamond
  I B I        I = Iron Ingot
  D I D        B = Barrel

Place the block. Right-click to open it.

GUI Slots:
  [Gear Slot]       = Top center — your Silent Gear item
  [Mat 1-5]         = Row of 5 — your material (lapis/redstone/quartz)
  [Apply Button]    = Click to apply the modifier and consume materials

Tiers:
  50  total items = Tier I
  150 total items = Tier II
  300 total items = Tier III

  Example: Fortune III = 5 stacks of lapis (5 × 64 = 320 ≥ 300)


MODIFIERS APPLIED
------------------
Material         Modifier         Silent Gear Trait
--------         --------         ----------------
Lapis Lazuli   → Fortune I/II/III    silentgear:fortune
Redstone Dust  → Mining Speed I/II/III   silentgear:efficiency
Nether Quartz  → Weapon Damage I/II/III  silentgear:attack_damage

Modifiers are applied using Silent Gear's own trait system via
GearData.setTraitLevel(). A vanilla enchantment fallback is used
if the direct API call fails.


TIP REMOVAL
-----------
All tip parts (silentgear:*_tip) are removed from Silent Gear's
PartManager during FMLCommonSetupEvent. This means:
  - Tips cannot be added to gear in the Part Station
  - Tip-related recipes still exist but produce no usable part
  - Existing gear with tips already applied retains them


ENCHANT PREVENTION
------------------
  - EnchantmentLevelSetEvent sets all levels to 0 for SG items
    → Enchanting table shows 0 slots, cannot proceed
  - AnvilUpdateEvent cancels any enchanting-via-anvil of SG items
    → Anvil rejects book + SG item combinations


FILE STRUCTURE
--------------
src/main/java/com/modifierworkbench/
  ModifierWorkbenchMod.java          Main mod class
  block/
    ModifierWorkbenchBlock.java      Block logic + opens menu
  blockentity/
    ModifierWorkbenchBlockEntity.java  7-slot container for the block
  menu/
    ModifierWorkbenchMenu.java         Server+client container menu
  screen/
    ModifierWorkbenchScreen.java       Client GUI renderer + Apply button
  network/
    ApplyModifierPacket.java           Client→Server packet for Apply button
  handler/
    ModEvents.java                     Enchant prevention + modifier logic
    TipRemovalHandler.java             Removes tip parts from SG registry
  registry/
    ModBlocks.java
    ModBlockEntities.java
    ModMenuTypes.java

src/main/resources/
  META-INF/neoforge.mods.toml        Mod metadata + SG dependency
  assets/modifierworkbench/
    blockstates/modifier_workbench.json
    models/block/modifier_workbench.json  (uses vanilla barrel textures)
    models/item/modifier_workbench.json
    lang/en_us.json
  data/modifierworkbench/
    recipes/modifier_workbench.json
    advancements/recipes/modifier_workbench.json


DEPENDENCIES REQUIRED AT RUNTIME
---------------------------------
  - Minecraft 1.21.1
  - NeoForge 21.1.172+
  - Silent Gear 3.6+ (for 1.21.1)

================================================================
