package com.modifierworkbench.handler;

import com.modifierworkbench.ModifierWorkbenchMod;
import com.modifierworkbench.blockentity.ModifierWorkbenchBlockEntity;
import com.modifierworkbench.menu.ModifierWorkbenchMenu;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.AnvilUpdateEvent;
import net.neoforged.neoforge.event.enchanting.EnchantmentLevelSetEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.silentchaos512.gear.api.item.GearItem;
import net.silentchaos512.gear.api.traits.ITrait;
import net.silentchaos512.gear.gear.trait.TraitManager;
import net.silentchaos512.gear.util.GearData;
import net.silentchaos512.gear.util.GearHelper;

import java.util.HashMap;
import java.util.Map;

/**
 * Handles all NeoForge event-driven behavior:
 *  1. Apply modifier button packet handling
 *  2. Prevent Silent Gear items from being enchanted via table or anvil
 *  3. Remove Tip upgrade on FML load
 */
public class ModEvents {

    // =========================================================================
    // TIER THRESHOLDS
    // =========================================================================
    private static final int TIER1_COUNT = 50;
    private static final int TIER2_COUNT = 150;
    private static final int TIER3_COUNT = 300;

    // =========================================================================
    // SILENT GEAR TRAIT IDs
    // =========================================================================
    private static final String TRAIT_FORTUNE      = "silentgear:fortune";
    private static final String TRAIT_EFFICIENCY   = "silentgear:efficiency"; // Mining Speed
    private static final String TRAIT_ATTACK_SPEED = "silentgear:attack_damage"; // Weapon Damage

    // =========================================================================
    // PREVENT ENCHANTING IN ENCHANTMENT TABLE
    // =========================================================================

    @SubscribeEvent
    public static void onEnchantmentLevelSet(EnchantmentLevelSetEvent event) {
        ItemStack stack = event.getItem();
        if (isSilentGearItem(stack)) {
            event.setLevel(0); // Force all enchantment slots to level 0 = not enchantable
        }
    }

    // =========================================================================
    // PREVENT ENCHANTING VIA ANVIL
    // =========================================================================

    @SubscribeEvent
    public static void onAnvilUpdate(AnvilUpdateEvent event) {
        ItemStack left = event.getLeft();
        ItemStack right = event.getRight();

        // Block enchanting a SG item via anvil (book + SG item or SG item + SG item)
        if (isSilentGearItem(left) || isSilentGearItem(right)) {
            // Only block if right side is an enchanted book or enchanted item
            boolean rightHasEnchants = !right.isEmpty() &&
                    right.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY).size() > 0;
            boolean rightIsBook = !right.isEmpty() &&
                    right.getItem() instanceof net.minecraft.world.item.EnchantedBookItem;

            if (rightHasEnchants || rightIsBook) {
                event.setCanceled(true);
            }
        }
    }

    // =========================================================================
    // APPLY MODIFIER - called from the network packet handler
    // =========================================================================

    /**
     * Apply the modifier to the gear item in slot 0 of the workbench.
     * Called on the server when the player clicks "Apply" in the GUI.
     */
    public static void applyModifier(ServerPlayer player, ModifierWorkbenchBlockEntity be) {
        ItemStack gearStack = be.getItem(ModifierWorkbenchBlockEntity.GEAR_SLOT);

        if (gearStack.isEmpty()) {
            sendFeedback(player, "§c[Modifier Workbench] No gear item in the top slot.");
            return;
        }

        if (!isSilentGearItem(gearStack)) {
            sendFeedback(player, "§c[Modifier Workbench] Item in the top slot is not a Silent Gear item.");
            return;
        }

        // Count total materials and determine type
        int totalCount = 0;
        String materialType = null;

        for (int i = ModifierWorkbenchBlockEntity.MAT_SLOT_START; i <= ModifierWorkbenchBlockEntity.MAT_SLOT_END; i++) {
            ItemStack mat = be.getItem(i);
            if (mat.isEmpty()) continue;

            String type = getMaterialType(mat);
            if (type == null) {
                sendFeedback(player, "§c[Modifier Workbench] Unknown material in slot " + (i + 1) +
                        ". Use lapis lazuli, redstone, or nether quartz.");
                return;
            }

            if (materialType != null && !materialType.equals(type)) {
                sendFeedback(player, "§c[Modifier Workbench] Mix of different materials detected. Use only one type.");
                return;
            }

            materialType = type;
            totalCount += mat.getCount();
        }

        if (materialType == null) {
            sendFeedback(player, "§c[Modifier Workbench] No material found in slots 2-6.");
            return;
        }

        int tier = getTier(totalCount);
        if (tier == 0) {
            sendFeedback(player, "§c[Modifier Workbench] Not enough material for Tier I. Need at least " +
                    TIER1_COUNT + " items total.");
            return;
        }

        String traitId = getTraitId(materialType);
        String modifierName = getModifierName(materialType, tier);

        // Apply the trait
        boolean success = applyTrait(gearStack, traitId, tier);

        if (success) {
            // Consume all materials from slots 1-5
            for (int i = ModifierWorkbenchBlockEntity.MAT_SLOT_START; i <= ModifierWorkbenchBlockEntity.MAT_SLOT_END; i++) {
                be.setItem(i, ItemStack.EMPTY);
            }
            be.setChanged();

            sendFeedback(player, "§a[Modifier Workbench] Applied §b" + modifierName + "§a to your Silent Gear item!");
            player.level().playSound(null, be.getBlockPos(),
                    net.minecraft.sounds.SoundEvents.ENCHANTMENT_TABLE_USE,
                    net.minecraft.sounds.SoundSource.BLOCKS, 1.0f, 1.0f + tier * 0.3f);
        } else {
            sendFeedback(player, "§c[Modifier Workbench] Failed to apply modifier. Make sure you have a valid Silent Gear item.");
        }
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    private static boolean isSilentGearItem(ItemStack stack) {
        return !stack.isEmpty() && stack.getItem() instanceof GearItem;
    }

    private static String getMaterialType(ItemStack stack) {
        if (stack.isEmpty()) return null;
        String id = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
        return switch (id) {
            case "minecraft:lapis_lazuli" -> "lapis";
            case "minecraft:redstone"     -> "redstone";
            case "minecraft:quartz"       -> "quartz";
            default -> null;
        };
    }

    private static int getTier(int count) {
        if (count >= TIER3_COUNT) return 3;
        if (count >= TIER2_COUNT) return 2;
        if (count >= TIER1_COUNT) return 1;
        return 0;
    }

    private static String getTraitId(String materialType) {
        return switch (materialType) {
            case "lapis"    -> TRAIT_FORTUNE;
            case "redstone" -> TRAIT_EFFICIENCY;
            case "quartz"   -> TRAIT_ATTACK_SPEED;
            default -> TRAIT_FORTUNE;
        };
    }

    private static String getModifierName(String materialType, int tier) {
        String suffix = switch (tier) {
            case 1 -> " I";
            case 2 -> " II";
            case 3 -> " III";
            default -> "";
        };
        return switch (materialType) {
            case "lapis"    -> "Fortune" + suffix;
            case "redstone" -> "Mining Speed" + suffix;
            case "quartz"   -> "Weapon Damage" + suffix;
            default -> "Modifier" + suffix;
        };
    }

    /**
     * Apply a Silent Gear trait at the given level to a gear item.
     *
     * Silent Gear stores gear data using GearData. Traits are part of
     * the computed stat cache, not stored directly — they come from parts.
     *
     * The clean approach for a standalone modifier system is to write
     * an "upgrade part" with the trait. However, the simplest reliable
     * API for direct trait injection is via GearData.addUpgradePart or
     * by adding the trait to the gear's "misc parts" list.
     *
     * In Silent Gear 3.x for 1.21, the public API for this is:
     *   GearData.addOrReplaceTrait(stack, traitResourceLocation, level)
     * If that method isn't available, we fall back to writing the
     * trait as an enhancement via a custom part.
     */
    private static boolean applyTrait(ItemStack gearStack, String traitId, int level) {
        try {
            net.minecraft.resources.ResourceLocation rl =
                    net.minecraft.resources.ResourceLocation.parse(traitId);

            // Try to get the trait from Silent Gear's trait manager
            ITrait trait = TraitManager.get(rl);
            if (trait == null) {
                ModifierWorkbenchMod.LOGGER.warn("[ModifierWorkbench] Trait '{}' not found in TraitManager.", traitId);
                return false;
            }

            // Use GearData to write trait directly
            // In SG 3.x the method is typically: GearData.setStatModifier or similar
            // We use the available API to set the trait level
            GearData.setTraitLevel(gearStack, rl, level);
            return true;

        } catch (Exception e) {
            ModifierWorkbenchMod.LOGGER.error("[ModifierWorkbench] Error applying trait '{}': {}", traitId, e.getMessage());
            // Fallback: apply as vanilla enchantment that SG respects
            return applyFallbackEnchantment(gearStack, traitId, level);
        }
    }

    /**
     * Fallback: Apply as vanilla enchantment if Silent Gear API isn't accessible.
     * Silent Gear reads vanilla enchantments and incorporates them into its stats.
     */
    private static boolean applyFallbackEnchantment(ItemStack stack, String traitId, int level) {
        try {
            net.minecraft.core.Holder<net.minecraft.world.item.enchantment.Enchantment> enchantment =
                    switch (traitId) {
                        case TRAIT_FORTUNE    -> stack.level().registryAccess()
                                .registryOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT)
                                .getHolderOrThrow(net.minecraft.world.item.enchantment.Enchantments.FORTUNE);
                        case TRAIT_EFFICIENCY -> stack.level().registryAccess()
                                .registryOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT)
                                .getHolderOrThrow(net.minecraft.world.item.enchantment.Enchantments.EFFICIENCY);
                        case TRAIT_ATTACK_SPEED -> stack.level().registryAccess()
                                .registryOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT)
                                .getHolderOrThrow(net.minecraft.world.item.enchantment.Enchantments.SHARPNESS);
                        default -> null;
                    };

            if (enchantment == null) return false;

            ItemEnchantments.Mutable mutable = new ItemEnchantments.Mutable(
                    stack.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY));
            mutable.set(enchantment, level);
            stack.set(DataComponents.ENCHANTMENTS, mutable.toImmutable());
            return true;

        } catch (Exception e) {
            ModifierWorkbenchMod.LOGGER.error("[ModifierWorkbench] Fallback enchantment also failed: {}", e.getMessage());
            return false;
        }
    }

    private static void sendFeedback(ServerPlayer player, String message) {
        player.sendSystemMessage(Component.literal(message));
    }
}
