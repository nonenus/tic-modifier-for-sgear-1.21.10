package com.modifierworkbench.handler;

import com.modifierworkbench.ModifierWorkbenchMod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.registries.RegisterEvent;

/**
 * Removes all Tip upgrade parts from Silent Gear's part registry.
 *
 * Silent Gear tip parts have IDs matching the pattern "silentgear:*_tip"
 * They are registered via Silent Gear's own deferred registry.
 * We remove them during FMLCommonSetupEvent after SG has registered them.
 */
public class TipRemovalHandler {

    @SubscribeEvent
    public static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(TipRemovalHandler::removeTipParts);
    }

    private static void removeTipParts() {
        try {
            // Silent Gear stores its parts in a PartManager / PartRegistry
            // In SG 3.x the registry is: net.silentchaos512.gear.gear.part.PartManager
            // Parts with category TIP are the ones to remove

            net.silentchaos512.gear.gear.part.PartManager.getValues().stream()
                    .filter(part -> {
                        String id = part.getId().toString();
                        return id.contains("_tip") || part.getType().equals(
                                net.silentchaos512.gear.api.part.PartType.TIP);
                    })
                    .forEach(part -> {
                        try {
                            net.silentchaos512.gear.gear.part.PartManager.remove(part.getId());
                            ModifierWorkbenchMod.LOGGER.info("[ModifierWorkbench] Removed tip part: {}", part.getId());
                        } catch (Exception e) {
                            ModifierWorkbenchMod.LOGGER.warn("[ModifierWorkbench] Could not remove tip part {}: {}",
                                    part.getId(), e.getMessage());
                        }
                    });

        } catch (Exception e) {
            ModifierWorkbenchMod.LOGGER.error("[ModifierWorkbench] Error during tip part removal: {}", e.getMessage());
        }
    }
}
