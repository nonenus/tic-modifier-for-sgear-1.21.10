package com.modifierworkbench.registry;

import com.modifierworkbench.ModifierWorkbenchMod;
import com.modifierworkbench.block.ModifierWorkbenchBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public class ModBlocks {

    public static final DeferredRegister.Blocks BLOCKS =
            DeferredRegister.createBlocks(ModifierWorkbenchMod.MOD_ID);

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(net.minecraft.core.registries.Registries.ITEM, ModifierWorkbenchMod.MOD_ID);

    public static final DeferredBlock<ModifierWorkbenchBlock> MODIFIER_WORKBENCH =
            BLOCKS.register("modifier_workbench", () -> new ModifierWorkbenchBlock(
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.COLOR_BROWN)
                            .strength(3.5f)
                            .sound(SoundType.WOOD)
                            .requiresCorrectToolForDrops()
            ));

    public static final DeferredHolder<Item, BlockItem> MODIFIER_WORKBENCH_ITEM =
            ITEMS.register("modifier_workbench", () -> new BlockItem(
                    MODIFIER_WORKBENCH.get(),
                    new Item.Properties()
            ));
}
