package com.modifierworkbench.registry;

import com.modifierworkbench.ModifierWorkbenchMod;
import com.modifierworkbench.blockentity.ModifierWorkbenchBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlockEntities {

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(net.minecraft.core.registries.Registries.BLOCK_ENTITY_TYPE, ModifierWorkbenchMod.MOD_ID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ModifierWorkbenchBlockEntity>> MODIFIER_WORKBENCH_BE =
            BLOCK_ENTITIES.register("modifier_workbench", () ->
                    BlockEntityType.Builder.of(ModifierWorkbenchBlockEntity::new, ModBlocks.MODIFIER_WORKBENCH.get())
                            .build(null));
}
