package com.modifierworkbench.screen;

import com.modifierworkbench.menu.ModifierWorkbenchMenu;
import com.modifierworkbench.network.ApplyModifierPacket;
import com.modifierworkbench.registry.ModMenuTypes;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import static com.modifierworkbench.ModifierWorkbenchMod.MOD_ID;

public class ModifierWorkbenchScreen extends AbstractContainerScreen<ModifierWorkbenchMenu> {

    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(MOD_ID, "textures/gui/modifier_workbench.png");

    // GUI dimensions
    private static final int GUI_WIDTH  = 176;
    private static final int GUI_HEIGHT = 196;

    private Button applyButton;

    public ModifierWorkbenchScreen(ModifierWorkbenchMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth  = GUI_WIDTH;
        this.imageHeight = GUI_HEIGHT;
        this.inventoryLabelY = GUI_HEIGHT - 94;
    }

    @Override
    protected void init() {
        super.init();

        // "Apply Modifier" button — centered at the bottom of the workbench area
        applyButton = addRenderableWidget(Button.builder(
                Component.literal("Apply Modifier"),
                btn -> onApplyClicked()
        ).bounds(leftPos + 50, topPos + 82, 75, 20).build());
    }

    private void onApplyClicked() {
        PacketDistributor.sendToServer(new ApplyModifierPacket(menu.blockPos));
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        // Draw the GUI background texture
        graphics.blit(RenderType::guiTextured, TEXTURE,
                leftPos, topPos, 0, 0, GUI_WIDTH, GUI_HEIGHT, 256, 256);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);

        // Render a small legend below the material slots
        int legendX = leftPos + 8;
        int legendY = topPos + 46;
        graphics.drawString(font, "§7Lapis=Fortune  Redstone=Mining Speed  Quartz=Weapon Dmg",
                legendX, legendY, 0x555555, false);
        graphics.drawString(font, "§750+=Tier I  150+=Tier II  300+=Tier III",
                legendX, legendY + 10, 0x555555, false);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(font, title, titleLabelX, titleLabelY, 0x404040, false);
        graphics.drawString(font, inventoryLabelName, inventoryLabelX, inventoryLabelY, 0x404040, false);
    }

    /**
     * Register this screen with the menu type. Called from the mod's clientSetup.
     */
    public static void register() {
        // Registration is done via the event below; this method is kept for clarity
    }

    // Called from mod event bus in client setup
    public static void onRegisterMenuScreens(RegisterMenuScreensEvent event) {
        event.register(ModMenuTypes.MODIFIER_WORKBENCH_MENU.get(), ModifierWorkbenchScreen::new);
    }
}
